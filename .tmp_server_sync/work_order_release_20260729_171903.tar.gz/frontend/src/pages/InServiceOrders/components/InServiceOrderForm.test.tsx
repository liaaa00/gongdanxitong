import { describe, expect, it, vi } from 'vitest';
import { render, screen } from '@testing-library/react';
import { Form } from 'antd';
import InServiceOrderForm, { type InServiceOrderFormValues } from './InServiceOrderForm';

vi.mock('@/services/customers', () => ({
  getCustomers: vi.fn().mockResolvedValue({
    list: [{ id: 'customer-1', customer_code: 'C001', customer_name: '测试客户', is_active: true }],
  }),
}));

vi.mock('@/services/departments', () => ({
  getDepartments: vi.fn().mockResolvedValue([
    { id: 'department-1', name: '业务一组', is_active: true },
  ]),
}));

function FormHarness() {
  const [form] = Form.useForm<InServiceOrderFormValues>();
  return <InServiceOrderForm form={form} />;
}

describe('InServiceOrderForm', () => {
  it('renders every field from the Excel required-field sheet', () => {
    render(<FormHarness />);

    for (const label of [
      '客户全称',
      '发起部门',
      '期望完成日期',
      '办理事由',
      '一级分类',
      '二级分类',
      '三级分类',
      '省份',
      '城市',
      '地区',
      '客户支付服务费',
      '附件',
      '订单内容',
    ]) {
      expect(screen.getByText(label)).toBeTruthy();
    }
    expect(screen.getByText('最多上传 5 个附件')).toBeTruthy();
    expect(screen.queryByText('联系电话')).toBeNull();
    expect(screen.queryByText('提交审批')).toBeNull();
  });
});
