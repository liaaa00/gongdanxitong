import { useEffect, useMemo, useState } from 'react';
import type { FormInstance } from 'antd';
import {
  Alert,
  Button,
  Col,
  DatePicker,
  Divider,
  Form,
  Input,
  InputNumber,
  Row,
  Select,
  Space,
  Upload,
  App,
} from 'antd';
import type { UploadFile, UploadProps } from 'antd';
import type { Dayjs } from 'dayjs';
import dayjs from 'dayjs';
import { PaperClipOutlined, UploadOutlined } from '@ant-design/icons';
import { getCustomers, type CustomerItem } from '@/services/customers';
import { getDepartments, type DepartmentItem } from '@/services/departments';
import { uploadAttachment } from '@/services/upload';
import {
  IN_SERVICE_BUSINESS_TYPE_OPTIONS,
  PROVINCES_27,
  getInServiceProcessOptions,
  getInServiceRequirementOptions,
  type InServiceBusinessType,
  type InServiceProcessType,
} from '@/constants/inService';
import type { InServiceOrderPayload } from '@/services/inServiceOrders';

export type InServiceOrderFormValues = InServiceOrderPayload;

interface InServiceOrderFormProps {
  form: FormInstance<InServiceOrderFormValues>;
  initialValues?: Partial<InServiceOrderFormValues>;
  readOnly?: boolean;
}

interface AttachmentFieldProps {
  value?: string[];
  onChange?: (value: string[]) => void;
  disabled?: boolean;
}

const formCol = { xs: 24, lg: 12 };

export function AttachmentField({ value = [], onChange, disabled }: AttachmentFieldProps) {
  const { message } = App.useApp();
  const [uploading, setUploading] = useState(false);
  const fileList: UploadFile[] = value.map((id, index) => ({
    uid: id,
    name: '附件' + (index + 1),
    status: 'done',
    response: { id },
  }));

  const customRequest: UploadProps['customRequest'] = async ({ file, onError, onSuccess }) => {
    if (value.length >= 5) {
      message.warning('最多上传 5 个附件');
      onError?.(new Error('最多上传 5 个附件'));
      return;
    }
    setUploading(true);
    try {
      const result = await uploadAttachment(file as File);
      const id = String(result.fileId || result.id || result.url || result.downloadUrl || '');
      if (!id) throw new Error('附件上传未返回文件标识');
      onChange?.([...value, id]);
      onSuccess?.({ id });
      message.success('附件上传成功');
    } catch (error) {
      onError?.(error as Error);
      message.error(error instanceof Error ? error.message : '附件上传失败');
    } finally {
      setUploading(false);
    }
  };

  return (
    <Upload
      fileList={fileList}
      customRequest={customRequest}
      disabled={disabled}
      maxCount={5}
      multiple
      onRemove={(file) => {
        onChange?.(value.filter((id) => id !== file.uid));
        return true;
      }}
      showUploadList={{ showRemoveIcon: !disabled, showDownloadIcon: false }}
    >
      {!disabled && value.length < 5 ? (
        <Button icon={<UploadOutlined />} loading={uploading}>上传附件</Button>
      ) : null}
    </Upload>
  );
}

export default function InServiceOrderForm({
  form,
  initialValues,
  readOnly = false,
}: InServiceOrderFormProps) {
  const { message } = App.useApp();
  const [customers, setCustomers] = useState<CustomerItem[]>([]);
  const [departments, setDepartments] = useState<DepartmentItem[]>([]);
  const [optionsLoaded, setOptionsLoaded] = useState(false);
  const businessType = Form.useWatch('businessType', form) as InServiceBusinessType | undefined;
  const processType = Form.useWatch('processType', form) as InServiceProcessType | undefined;

  useEffect(() => {
    Promise.all([getCustomers({ page: 1, pageSize: 100 }), getDepartments()])
      .then(([customerResult, departmentResult]) => {
        setCustomers(customerResult.list.filter((item) => item.is_active !== false));
        setDepartments(departmentResult.filter((item) => item.is_active !== false));
      })
      .catch(() => message.warning('客户或部门选项加载失败，请稍后刷新'))
      .finally(() => setOptionsLoaded(true));
  }, [message]);

  const customerOptions = useMemo(() => customers.map((item) => ({
    value: item.id,
    label: [item.customer_code, item.customer_name].filter(Boolean).join(' - '),
  })), [customers]);
  const departmentOptions = useMemo(() => departments.map((item) => ({
    value: item.id,
    label: item.name,
  })), [departments]);
  const processOptions = getInServiceProcessOptions(businessType);
  const requirementOptions = getInServiceRequirementOptions(processType);

  return (
    <Form<InServiceOrderFormValues>
      form={form}
      layout="vertical"
      initialValues={{ attachments: [], ...initialValues }}
      disabled={readOnly}
      requiredMark
    >
      {optionsLoaded && (customerOptions.length === 0 || departmentOptions.length === 0) ? (
        <Alert
          type="warning"
          showIcon
          style={{ marginBottom: 16 }}
          message="客户或部门选项暂不可用"
          description="请确认当前账号具备客户、部门基础数据读取权限后刷新页面。"
        />
      ) : null}

      <Divider orientation="left">订单信息</Divider>
      <Row gutter={16}>
        <Col {...formCol}>
          <Form.Item name="customerId" label="客户全称" rules={[{ required: true, message: '请选择客户' }]}>
            <Select showSearch optionFilterProp="label" placeholder="请选择客户" options={customerOptions} />
          </Form.Item>
        </Col>
        <Col {...formCol}>
          <Form.Item name="departmentId" label="发起部门" rules={[{ required: true, message: '请选择发起部门' }]}>
            <Select showSearch optionFilterProp="label" placeholder="请选择发起部门" options={departmentOptions} />
          </Form.Item>
        </Col>
        <Col {...formCol}>
          <Form.Item
            name="expectedCompletionDate"
            label="期望完成日期"
            rules={[{ required: true, message: '请选择期望完成日期' }]}
            getValueProps={(value?: string) => ({ value: value ? dayjs(value) : null })}
            normalize={(value: Dayjs | null) => value?.format('YYYY-MM-DD')}
          >
            <DatePicker style={{ width: '100%' }} placeholder="请选择期望完成日期" />
          </Form.Item>
        </Col>
        <Col {...formCol}>
          <Form.Item
            name="businessReason"
            label="办理事由"
            rules={[{ required: true, message: '请输入办理事由' }, { max: 512 }]}
          >
            <Input placeholder="简要说明本次办理原因" maxLength={512} />
          </Form.Item>
        </Col>
      </Row>

      <Divider orientation="left">业务分类</Divider>
      <Row gutter={16}>
        <Col {...formCol}>
          <Form.Item name="businessType" label="一级分类" rules={[{ required: true, message: '请选择一级分类' }]}>
            <Select
              placeholder="请选择一级分类"
              options={IN_SERVICE_BUSINESS_TYPE_OPTIONS}
              onChange={() => form.setFieldsValue({ processType: undefined, requirementType: undefined })}
            />
          </Form.Item>
        </Col>
        <Col {...formCol}>
          <Form.Item name="processType" label="二级分类" rules={[{ required: true, message: '请选择二级分类' }]}>
            <Select
              placeholder="请先选择一级分类"
              disabled={readOnly || !businessType}
              options={processOptions}
              onChange={() => form.setFieldsValue({ requirementType: undefined })}
            />
          </Form.Item>
        </Col>
        <Col {...formCol}>
          <Form.Item
            name="requirementType"
            label="三级分类"
            rules={[{ required: requirementOptions.length > 0, message: '请选择三级分类' }]}
          >
            <Select
              allowClear
              placeholder={requirementOptions.length > 0 ? '请选择三级分类' : '当前二级分类无三级项'}
              disabled={readOnly || requirementOptions.length === 0}
              options={requirementOptions}
            />
          </Form.Item>
        </Col>
      </Row>

      <Divider orientation="left">缴纳地与费用</Divider>
      <Row gutter={16}>
        <Col {...formCol}>
          <Form.Item name="province" label="省份" rules={[{ required: true, message: '请选择省份' }]}>
            <Select
              showSearch
              optionFilterProp="label"
              placeholder="请选择省份"
              options={PROVINCES_27.map((value) => ({ value, label: value }))}
            />
          </Form.Item>
        </Col>
        <Col {...formCol}>
          <Form.Item name="city" label="城市" rules={[{ required: true, message: '请输入城市' }, { max: 50 }]}>
            <Input placeholder="例如：南京市" maxLength={50} />
          </Form.Item>
        </Col>
        <Col {...formCol}>
          <Form.Item name="district" label="地区" rules={[{ required: true, message: '请输入地区' }, { max: 50 }]}>
            <Input placeholder="例如：建邺区" maxLength={50} />
          </Form.Item>
        </Col>
        <Col {...formCol}>
          <Form.Item
            name="serviceFee"
            label="客户支付服务费"
            rules={[{ required: true, message: '请输入服务费' }]}
          >
            <InputNumber min={0} precision={2} prefix="¥" placeholder="0.00" style={{ width: '100%' }} />
          </Form.Item>
        </Col>
      </Row>

      <Divider orientation="left">材料与订单内容</Divider>
      <Row gutter={16}>
        <Col span={24}>
          <Form.Item name="attachments" label="附件" extra={readOnly ? undefined : '最多上传 5 个附件'}>
            <AttachmentField disabled={readOnly} />
          </Form.Item>
        </Col>
        <Col span={24}>
          <Form.Item
            name="businessDescription"
            label="订单内容"
            rules={[
              { required: true, message: '请详细描述订单内容' },
              { max: 5000, message: '订单内容不能超过 5000 个字符' },
            ]}
          >
            <Input.TextArea rows={5} maxLength={5000} showCount={!readOnly} placeholder="请详细描述办理事项、材料情况和期望结果" />
          </Form.Item>
        </Col>
      </Row>

      {readOnly && (initialValues?.attachments?.length || 0) > 0 ? (
        <Space size={4}><PaperClipOutlined />共 {initialValues?.attachments?.length} 个附件</Space>
      ) : null}
    </Form>
  );
}
