import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { PageContainer } from '@ant-design/pro-components';
import { App, Button, Card, Form, Space } from 'antd';
import { ArrowLeftOutlined, SendOutlined } from '@ant-design/icons';
import InServiceOrderForm, { type InServiceOrderFormValues } from './components/InServiceOrderForm';
import { createInServiceOrder } from '@/services/inServiceOrders';

export default function InServiceOrderNew() {
  const navigate = useNavigate();
  const { message, modal } = App.useApp();
  const [form] = Form.useForm<InServiceOrderFormValues>();
  const [submitting, setSubmitting] = useState(false);

  const handleSubmit = async () => {
    try {
      const values = await form.validateFields();
      setSubmitting(true);
      const order = await createInServiceOrder(values);
      modal.success({
        title: '单项业务已创建',
        content: order.handlerName
          ? `工单 ${order.orderNo} 已自动派发给 ${order.handlerName}，当前待受理。`
          : `工单 ${order.orderNo} 已创建，当前待受理。`,
        okText: '查看工单',
        onOk: () => navigate('/in-service/' + order.id),
      });
    } catch (error) {
      if ((error as { errorFields?: unknown[] })?.errorFields) {
        message.error('表单校验未通过，请检查红色提示字段');
      } else {
        message.error(error instanceof Error ? error.message : '创建单项业务失败');
      }
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <PageContainer
      header={{
        title: '新建单项业务',
        extra: [
          <Button key="back" icon={<ArrowLeftOutlined />} onClick={() => navigate('/in-service')}>
            返回列表
          </Button>,
        ],
      }}
    >
      <Card size="small">
        <InServiceOrderForm form={form} />
        <Space>
          <Button type="primary" icon={<SendOutlined />} loading={submitting} onClick={handleSubmit}>
            提交工单
          </Button>
          <Button onClick={() => navigate('/in-service')}>取消</Button>
        </Space>
      </Card>
    </PageContainer>
  );
}
