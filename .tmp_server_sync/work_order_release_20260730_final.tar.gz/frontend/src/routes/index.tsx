import { Suspense, lazy, useEffect } from 'react';
import { Routes, Route, Navigate, Outlet, useLocation } from 'react-router-dom';
import { Spin } from 'antd';
import { useUserStore } from '@/stores/userStore';
import ErrorBoundary from '@/components/ErrorBoundary';
import { canAccessPath } from '@/config/routeVisibility';

const LoginPage = lazy(() => import('@/pages/Login'));
const ChangePasswordPage = lazy(() => import('@/pages/ChangePassword'));
const Dashboard = lazy(() => import('@/pages/Dashboard'));
const Forbidden = lazy(() => import('@/pages/403'));
const NotFound = lazy(() => import('@/pages/404'));
const BasicLayout = lazy(() => import('@/layouts/BasicLayout'));

const WorkOrders = lazy(() => import('@/pages/WorkOrders'));
const WorkOrdersNew = lazy(() => import('@/pages/WorkOrders/New'));
const WorkOrdersImport = lazy(() => import('@/pages/WorkOrders/Import'));
const WorkOrdersDetail = lazy(() => import('@/pages/WorkOrders/Detail'));
const OnboardingModule = lazy(() => import('@/pages/OnboardingModule'));
const MyDispatched = lazy(() => import('@/pages/MyDispatched'));
const MyDispatchedDetail = lazy(() => import('@/pages/MyDispatched/Detail'));
const TeamDispatched = lazy(() => import('@/pages/TeamDispatched'));
const HistoryWorkOrders = lazy(() => import('@/pages/HistoryWorkOrders'));
const ExportTemplates = lazy(() => import('@/pages/ExportTemplates'));
const NotificationsPage = lazy(() => import('@/pages/Notifications'));
const InServiceOrderList = lazy(() => import('@/pages/InServiceOrders'));
const InServiceOrderNew = lazy(() => import('@/pages/InServiceOrders/New'));
const InServiceOrderDetail = lazy(() => import('@/pages/InServiceOrders/Detail'));
const OutOfProvinceList = lazy(() => import('@/pages/OutOfProvince'));
const OutOfProvinceImport = lazy(() => import('@/pages/OutOfProvince/Import'));
const OutOfProvinceForm = lazy(() => import('@/pages/OutOfProvince/Form'));
const OutOfProvinceOrderList = lazy(() => import('@/pages/OutOfProvinceOrders'));
const OutOfProvinceOrderNew = lazy(() => import('@/pages/OutOfProvinceOrders/New'));
const OutOfProvinceOrderDetail = lazy(() => import('@/pages/OutOfProvinceOrders/Detail'));

const RenewalList = lazy(() => import('@/pages/Renewal'));
const RenewalNew = lazy(() => import('@/pages/Renewal/New'));
const RenewalDetail = lazy(() => import('@/pages/Renewal/Detail'));
const ResignationList = lazy(() => import('@/pages/Resignation'));
const ResignationNew = lazy(() => import('@/pages/Resignation/New'));
const ResignationDetail = lazy(() => import('@/pages/Resignation/Detail'));
const ResignationCert = lazy(() => import('@/pages/Resignation/Cert'));
const BenefitList = lazy(() => import('@/pages/Benefit'));
const BenefitNew = lazy(() => import('@/pages/Benefit/New'));
const BenefitDetail = lazy(() => import('@/pages/Benefit/Detail'));

const AdminUsers = lazy(() => import('@/pages/Admin/Users'));
const AdminRoles = lazy(() => import('@/pages/Admin/Roles'));
const AdminDepartments = lazy(() => import('@/pages/Admin/Departments'));
const AdminCustomers = lazy(() => import('@/pages/Admin/Customers'));
const AdminModuleConfig = lazy(() => import('@/pages/Admin/ModuleConfig'));
const AdminFields = lazy(() => import('@/pages/Admin/Fields'));
const AdminFieldPermissions = lazy(() => import('@/pages/Admin/FieldPermissions'));
const AdminImportTemplates = lazy(() => import('@/pages/Admin/ImportTemplates'));
const AdminDispatchConfig = lazy(() => import('@/pages/Admin/DispatchConfig'));
const AdminWorkflows = lazy(() => import('@/pages/Admin/Workflows'));
const AdminWorkflowEditor = lazy(() => import('@/pages/Admin/Workflows/Editor'));
const AdminExportTemplates = lazy(() => import('@/pages/Admin/ExportTemplates'));
const AdminDetailViewTemplates = lazy(() => import('@/pages/Admin/DetailViewTemplates'));
const AdminLogs = lazy(() => import('@/pages/Admin/Logs'));
const AdminAISettings = lazy(() => import('@/pages/Admin/AISettings'));
const AdminSystemSettings = lazy(() => import('@/pages/Admin/SystemSettings'));
const AdminLoginDebug = lazy(() => import('@/pages/Admin/LoginDebug'));
const AdminCustomerAssignees = lazy(() => import('@/pages/Admin/CustomerAssignees'));
const WorkOrderPool = lazy(() => import('@/pages/WorkOrderPool'));

const Loading: React.FC = () => (
  <div style={{ display: 'flex', justifyContent: 'center', alignItems: 'center', height: '100vh' }}>
    <Spin size="large" />
  </div>
);

/** 为每个路由节点提供局部 ErrorBoundary，一个页面崩不会拖垮整个应用 */
const RouteGuard: React.FC<{ moduleName: string; children: React.ReactNode }> = ({ moduleName, children }) => (
  <ErrorBoundary moduleName={moduleName}>
    <Suspense fallback={<Loading />}>
      {children}
    </Suspense>
  </ErrorBoundary>
);

const PrivateRoute: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { isLoggedIn, user, loading, fetchUser, mustChangePassword } = useUserStore();
  const location = useLocation();
  useEffect(() => {
    if (isLoggedIn && !user && !loading) {
      void fetchUser();
    }
  }, [isLoggedIn, user, location.pathname, loading, fetchUser]);

  if (!isLoggedIn) return <Navigate to="/login" replace />;
  // 仅在「尚无用户、首次阻塞加载」时显示全屏 Loading；
  // 已有用户时的后台重校验（visibilitychange/storage/切菜单触发的 /auth/me）
  // 不得卸载整个布局，否则会销毁 KeepAliveOutlet 缓存导致页面状态丢失。
  if (!user) return <Loading />;

  // ★ 首登强制改密：拦截所有非改密页路由
  const path = window.location.pathname;
  if (mustChangePassword && path !== '/change-password' && path !== '/login') {
    return <Navigate to="/change-password" replace />;
  }

  return <>{children}</>;
};

const RoleRoute: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { user } = useUserStore();
  const location = useLocation();
  if (!user) return <Loading />;
  if (!canAccessPath(location.pathname, user.roles, user.permissions)) return <Navigate to="/403" replace />;
  return <>{children}</>;
};

const AppRoutes: React.FC = () => (
  <ErrorBoundary moduleName="路由层">
    <Routes>
      <Route path="/login" element={<RouteGuard moduleName="北仑登录页"><LoginPage /></RouteGuard>} />
      <Route
        path="/zhejiang-login"
        element={(
          <RouteGuard moduleName="浙江自签登录页">
            <LoginPage businessScope="out_of_province" />
          </RouteGuard>
        )}
      />
      <Route path="/change-password" element={<RouteGuard moduleName="修改密码"><ChangePasswordPage /></RouteGuard>} />
      <Route path="/403" element={<RouteGuard moduleName="403"><Forbidden /></RouteGuard>} />
      <Route path="/404" element={<RouteGuard moduleName="404"><NotFound /></RouteGuard>} />
      <Route
        path="/"
        element={
          <PrivateRoute>
            <RouteGuard moduleName="主布局">
              <BasicLayout />
            </RouteGuard>
          </PrivateRoute>
        }
      >
        <Route index element={<Navigate to="/dashboard" replace />} />
        <Route path="dashboard" element={<RoleRoute><RouteGuard moduleName="仪表盘"><Dashboard /></RouteGuard></RoleRoute>} />

        <Route path="work-orders" element={<RoleRoute><RouteGuard moduleName="工单列表"><WorkOrders /></RouteGuard></RoleRoute>} />
        <Route path="work-orders/new" element={<RoleRoute><RouteGuard moduleName="新建工单"><WorkOrdersNew /></RouteGuard></RoleRoute>} />
        <Route path="work-orders/import" element={<RoleRoute><RouteGuard moduleName="批量导入"><WorkOrdersImport /></RouteGuard></RoleRoute>} />
        <Route path="work-orders/:id" element={<RoleRoute><RouteGuard moduleName="工单详情"><WorkOrdersDetail /></RouteGuard></RoleRoute>} />

        <Route path="out-of-province" element={<RoleRoute><RouteGuard moduleName="省外增减员列表"><OutOfProvinceList /></RouteGuard></RoleRoute>} />
        <Route path="out-of-province/import" element={<RoleRoute><RouteGuard moduleName="省外增减员导入"><OutOfProvinceImport /></RouteGuard></RoleRoute>} />
        <Route path="out-of-province/new" element={<RoleRoute><RouteGuard moduleName="省外表单占位"><OutOfProvinceForm /></RouteGuard></RoleRoute>} />
        <Route
          path="out-of-province/increase"
          element={<RoleRoute><RouteGuard moduleName="省外增员"><InServiceOrderList orderKind="out_of_province_increase" businessScope="out_of_province" createPath="/out-of-province/increase/new" /></RouteGuard></RoleRoute>}
        />
        <Route
          path="out-of-province/increase/new"
          element={<RoleRoute><RouteGuard moduleName="新建省外增员"><InServiceOrderNew orderKind="out_of_province_increase" listPath="/out-of-province/increase" businessScope="out_of_province" /></RouteGuard></RoleRoute>}
        />
        <Route
          path="out-of-province/decrease"
          element={<RoleRoute><RouteGuard moduleName="省外减员"><InServiceOrderList orderKind="out_of_province_decrease" businessScope="out_of_province" createPath="/out-of-province/decrease/new" /></RouteGuard></RoleRoute>}
        />
        <Route
          path="out-of-province/decrease/new"
          element={<RoleRoute><RouteGuard moduleName="新建省外减员"><InServiceOrderNew orderKind="out_of_province_decrease" listPath="/out-of-province/decrease" businessScope="out_of_province" /></RouteGuard></RoleRoute>}
        />
        <Route
          path="out-of-province/single-business"
          element={<RoleRoute><RouteGuard moduleName="省外单项业务"><InServiceOrderList orderKind="single_business" businessScope="out_of_province" createPath="/out-of-province/single-business/new" /></RouteGuard></RoleRoute>}
        />
        <Route
          path="out-of-province/single-business/new"
          element={<RoleRoute><RouteGuard moduleName="新建省外单项业务"><InServiceOrderNew orderKind="single_business" listPath="/out-of-province/single-business" businessScope="out_of_province" /></RouteGuard></RoleRoute>}
        />

        <Route path="out-of-province/orders" element={<RoleRoute><RouteGuard moduleName="省外派单列表"><OutOfProvinceOrderList /></RouteGuard></RoleRoute>} />
        <Route path="out-of-province/orders/new" element={<RoleRoute><RouteGuard moduleName="新建省外派单"><OutOfProvinceOrderNew /></RouteGuard></RoleRoute>} />
        <Route path="out-of-province/orders/:id" element={<RoleRoute><RouteGuard moduleName="省外派单详情"><OutOfProvinceOrderDetail /></RouteGuard></RoleRoute>} />

        <Route path="onboarding/:moduleCode" element={<RoleRoute><RouteGuard moduleName="入职模块"><OnboardingModule /></RouteGuard></RoleRoute>} />

        <Route path="my-work/initiated" element={<RoleRoute><RouteGuard moduleName="我发起的"><MyDispatched mode="initiated" /></RouteGuard></RoleRoute>} />
        <Route path="my-work/returned" element={<RoleRoute><RouteGuard moduleName="我的退回"><MyDispatched mode="returned" /></RouteGuard></RoleRoute>} />
        <Route path="my-work/pending" element={<RoleRoute><RouteGuard moduleName="我的待办"><MyDispatched mode="pending" /></RouteGuard></RoleRoute>} />
        <Route path="my-work/done" element={<RoleRoute><RouteGuard moduleName="我的已办"><MyDispatched mode="done" /></RouteGuard></RoleRoute>} />
        <Route path="my-work/team" element={<RoleRoute><RouteGuard moduleName="团队工单"><TeamDispatched /></RouteGuard></RoleRoute>} />
        <Route path="my-work/history" element={<RoleRoute><RouteGuard moduleName="历史工单"><HistoryWorkOrders /></RouteGuard></RoleRoute>} />

        <Route path="my-dispatched" element={<RoleRoute><RouteGuard moduleName="我的子工单"><MyDispatched /></RouteGuard></RoleRoute>} />
        <Route path="my-dispatched/:id" element={<RoleRoute><RouteGuard moduleName="子工单详情"><MyDispatchedDetail /></RouteGuard></RoleRoute>} />

        <Route path="team-dispatched" element={<RoleRoute><RouteGuard moduleName="部门子工单"><TeamDispatched /></RouteGuard></RoleRoute>} />

        <Route path="export-templates" element={<RoleRoute><RouteGuard moduleName="导出模板"><ExportTemplates /></RouteGuard></RoleRoute>} />
        <Route path="notifications" element={<RoleRoute><RouteGuard moduleName="消息通知"><NotificationsPage /></RouteGuard></RoleRoute>} />

        <Route path="in-service" element={<RoleRoute><RouteGuard moduleName="单项业务办理"><InServiceOrderList /></RouteGuard></RoleRoute>} />
        <Route path="in-service/new" element={<RoleRoute><RouteGuard moduleName="新建单项业务"><InServiceOrderNew /></RouteGuard></RoleRoute>} />
        <Route
          path="in-service/certificates"
          element={<RoleRoute><RouteGuard moduleName="证明开具"><InServiceOrderList orderKind="certificate" createPath="/in-service/certificates/new" /></RouteGuard></RoleRoute>}
        />
        <Route
          path="in-service/certificates/new"
          element={<RoleRoute><RouteGuard moduleName="发起证明开具"><InServiceOrderNew orderKind="certificate" listPath="/in-service/certificates" /></RouteGuard></RoleRoute>}
        />
        <Route path="in-service/:id" element={<RoleRoute><RouteGuard moduleName="独立工单详情"><InServiceOrderDetail /></RouteGuard></RoleRoute>} />

        {/* 字段权限入口仅管理员可访问；保留旧路径并由 RoleRoute 按 ADMIN 权限拦截。*/}
        <Route path="my-field-permissions" element={<RoleRoute><RouteGuard moduleName="字段权限"><AdminFieldPermissions /></RouteGuard></RoleRoute>} />

        <Route path="renewal" element={<RoleRoute><RouteGuard moduleName="续签列表"><RenewalList /></RouteGuard></RoleRoute>} />
        <Route path="renewal/new" element={<RoleRoute><RouteGuard moduleName="新建续签"><RenewalNew /></RouteGuard></RoleRoute>} />
        <Route path="renewal/:id" element={<RoleRoute><RouteGuard moduleName="续签详情"><RenewalDetail /></RouteGuard></RoleRoute>} />

        <Route path="resignation" element={<RoleRoute><RouteGuard moduleName="离职列表"><ResignationList /></RouteGuard></RoleRoute>} />
        <Route path="resignation/new" element={<RoleRoute><RouteGuard moduleName="新建离职"><ResignationNew /></RouteGuard></RoleRoute>} />
        <Route path="resignation/:id" element={<RoleRoute><RouteGuard moduleName="离职详情"><ResignationDetail /></RouteGuard></RoleRoute>} />
        <Route path="resignation/:id/cert" element={<RoleRoute><RouteGuard moduleName="离职材料收集"><ResignationCert /></RouteGuard></RoleRoute>} />
        <Route
          path="resignation-certificates"
          element={<RoleRoute><RouteGuard moduleName="离职证明"><InServiceOrderList orderKind="resignation_certificate" createPath="/resignation-certificates/new" /></RouteGuard></RoleRoute>}
        />
        <Route
          path="resignation-certificates/new"
          element={<RoleRoute><RouteGuard moduleName="发起离职证明"><InServiceOrderNew orderKind="resignation_certificate" listPath="/resignation-certificates" /></RouteGuard></RoleRoute>}
        />

        <Route path="benefit" element={<RoleRoute><RouteGuard moduleName="待遇申报列表"><BenefitList /></RouteGuard></RoleRoute>} />
        <Route path="benefit/new" element={<RoleRoute><RouteGuard moduleName="新建申报"><BenefitNew /></RouteGuard></RoleRoute>} />
        <Route path="benefit/:id" element={<RoleRoute><RouteGuard moduleName="申报详情"><BenefitDetail /></RouteGuard></RoleRoute>} />

        <Route
          path="admin"
          element={
            <RoleRoute>
              <RouteGuard moduleName="管理后台">
                <Outlet />
              </RouteGuard>
            </RoleRoute>
          }
        >
          <Route index element={<Navigate to="/admin/users" replace />} />
          <Route path="users" element={<RouteGuard moduleName="用户管理"><AdminUsers /></RouteGuard>} />
          <Route path="roles" element={<RouteGuard moduleName="角色管理"><AdminRoles /></RouteGuard>} />
          <Route path="departments" element={<RouteGuard moduleName="部门管理"><AdminDepartments /></RouteGuard>} />
          <Route path="customers" element={<RouteGuard moduleName="客户管理"><AdminCustomers /></RouteGuard>} />
          <Route path="fields" element={<RouteGuard moduleName="表单字段管理"><AdminFields /></RouteGuard>} />
          <Route path="import-templates" element={<RouteGuard moduleName="导入模板配置"><AdminImportTemplates /></RouteGuard>} />
          <Route path="module-config" element={<RouteGuard moduleName="模块化配置"><AdminModuleConfig /></RouteGuard>} />
          <Route path="field-permissions" element={<RouteGuard moduleName="字段填写权限"><AdminFieldPermissions /></RouteGuard>} />
          <Route path="dispatch-config" element={<RouteGuard moduleName="派发配置"><AdminDispatchConfig /></RouteGuard>} />
          <Route path="workflows" element={<RouteGuard moduleName="工单流程配置"><AdminWorkflows /></RouteGuard>} />
          <Route path="workflow-config" element={<RouteGuard moduleName="工单流程配置"><AdminWorkflows /></RouteGuard>} />
          <Route path="workflows/:id" element={<RouteGuard moduleName="工单流程编辑"><AdminWorkflowEditor /></RouteGuard>} />
          <Route path="export-templates" element={<RouteGuard moduleName="导出模板配置"><AdminExportTemplates /></RouteGuard>} />
          <Route path="detail-view-templates" element={<RouteGuard moduleName="详情页字段配置"><AdminDetailViewTemplates /></RouteGuard>} />
          <Route path="logs" element={<RouteGuard moduleName="操作日志"><AdminLogs /></RouteGuard>} />
          <Route path="ai-settings" element={<RouteGuard moduleName="智能设置"><AdminAISettings /></RouteGuard>} />
          <Route path="system-settings" element={<RouteGuard moduleName="系统设置"><AdminSystemSettings /></RouteGuard>} />
          <Route path="login-debug" element={<RouteGuard moduleName="登录诊断"><AdminLoginDebug /></RouteGuard>} />
          <Route path="customer-assignees" element={<RouteGuard moduleName="业务员客户绑定"><AdminCustomerAssignees /></RouteGuard>} />
        </Route>

        <Route path="work-order-pool" element={<RoleRoute><RouteGuard moduleName="待认领工单"><WorkOrderPool /></RouteGuard></RoleRoute>} />
        <Route path="*" element={<RouteGuard moduleName="404"><NotFound /></RouteGuard>} />
      </Route>
    </Routes>
  </ErrorBoundary>
);

export default AppRoutes;
